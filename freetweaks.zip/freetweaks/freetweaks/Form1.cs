using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Net.Http;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace freetweaks
{
    public partial class Form1 : Form
    {
        private List<Particle> particles;
        private Random random;
        private string downloadedFilePath;

        public Form1()
        {
            InitializeComponent();
            particles = new List<Particle>();
            random = new Random();
            this.DoubleBuffered = true;  // Para reducir el parpadeo
        }

        private async void Form1_Load(object sender, EventArgs e)
        {
            // Descargar el archivo al cargar el formulario
            string url = "https://github.com/astrotweaks/astrostuff/raw/main/free.zip"; // Reemplaza con la URL de tu archivo
            string tempPath = Path.GetTempPath();
            string zipFilePath = Path.Combine(tempPath, "free.zip");
            downloadedFilePath = Path.Combine(tempPath, "free.cmd");

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    var response = await client.GetAsync(url);
                    response.EnsureSuccessStatusCode();
                    var content = await response.Content.ReadAsByteArrayAsync();
                    await File.WriteAllBytesAsync(zipFilePath, content);
                }

                // Descomprimir el archivo ZIP
                ZipFile.ExtractToDirectory(zipFilePath, tempPath);

                // Eliminar el archivo ZIP descargado
                File.Delete(zipFilePath);
            }
            catch (HttpRequestException ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            // Configurar el Timer
            timer1.Interval = 30;
            timer1.Tick += Timer1_Tick;
            timer1.Start();
        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            // Agregar una nueva part�cula en una posici�n aleatoria en la parte superior del formulario
            float startX = (float)(random.NextDouble() * this.ClientSize.Width);
            float speedY = (float)(random.NextDouble() * 2 + 1); // Velocidad positiva entre 1 y 3

            particles.Add(new Particle(new PointF(startX, 0), new PointF(0, speedY), 1.0f));

            // Actualizar las part�culas existentes
            foreach (var particle in particles)
            {
                particle.Update();
            }

            // Eliminar part�culas que ya no tienen vida
            particles.RemoveAll(p => p.Life <= 0);

            // Redibujar el formulario
            this.Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            // Dibujar cada part�cula
            foreach (var particle in particles)
            {
                particle.Draw(e.Graphics);
            }
        }

        // Evento de clic del bot�n Guna
        private async void gunaButton1_Click(object sender, EventArgs e)
        {
            // Ejecutar el archivo descargado sin mostrar la consola
            if (File.Exists(downloadedFilePath))
            {
                var processInfo = new ProcessStartInfo(downloadedFilePath)
                {
                    CreateNoWindow = true,
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true
                };

                var process = new Process { StartInfo = processInfo };

                var tcs = new TaskCompletionSource<bool>();
                process.Exited += (s, ea) => tcs.SetResult(true);
                process.EnableRaisingEvents = true;

                process.Start();
                await tcs.Task;

                MessageBox.Show("Done!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("El archivo no se encontr�.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }

    // Clase Particle
    public class Particle
    {
        public PointF Position { get; set; }
        public PointF Velocity { get; set; }
        public float Life { get; set; }

        public Particle(PointF position, PointF velocity, float life)
        {
            Position = position;
            Velocity = velocity;
            Life = life;
        }

        public void Update()
        {
            Position = new PointF(Position.X + Velocity.X, Position.Y + Velocity.Y);
            Life -= 0.01f; // Disminuir la vida m�s lentamente para ver mejor las part�culas
        }

        public void Draw(Graphics g)
        {
            using (Brush brush = new SolidBrush(Color.FromArgb((int)(Life * 255), Color.White)))
            {
                g.FillEllipse(brush, Position.X, Position.Y, 5, 5);
            }
        }
    }
}
