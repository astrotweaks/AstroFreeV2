﻿namespace freetweaks
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private Guna.UI2.WinForms.Guna2Button gunaButton1;
        private Guna.UI2.WinForms.Guna2BorderlessForm guna2BorderlessForm1;
        private System.Windows.Forms.Timer timer1;
        private Guna.UI2.WinForms.Guna2ControlBox guna2ControlBox1;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel2;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            gunaButton1 = new Guna.UI2.WinForms.Guna2Button();
            guna2BorderlessForm1 = new Guna.UI2.WinForms.Guna2BorderlessForm(components);
            timer1 = new System.Windows.Forms.Timer(components);
            guna2ControlBox1 = new Guna.UI2.WinForms.Guna2ControlBox();
            guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            SuspendLayout();
            // 
            // gunaButton1
            // 
            gunaButton1.Animated = true;
            gunaButton1.BackColor = Color.Transparent;
            gunaButton1.BorderColor = Color.Cyan;
            gunaButton1.BorderRadius = 20;
            gunaButton1.BorderThickness = 2;
            gunaButton1.CustomizableEdges = customizableEdges1;
            gunaButton1.FillColor = Color.Black;
            gunaButton1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            gunaButton1.ForeColor = Color.Cyan;
            gunaButton1.Location = new Point(78, 279);
            gunaButton1.Margin = new Padding(4, 3, 4, 3);
            gunaButton1.Name = "gunaButton1";
            gunaButton1.PressedColor = Color.FromArgb(0, 192, 192);
            gunaButton1.ShadowDecoration.CustomizableEdges = customizableEdges2;
            gunaButton1.Size = new Size(138, 51);
            gunaButton1.TabIndex = 0;
            gunaButton1.Text = "Tweak your pc!";
            gunaButton1.UseTransparentBackground = true;
            gunaButton1.Click += gunaButton1_Click;
            // 
            // guna2BorderlessForm1
            // 
            guna2BorderlessForm1.ContainerControl = this;
            guna2BorderlessForm1.DockIndicatorTransparencyValue = 0.6D;
            guna2BorderlessForm1.DragEndTransparencyValue = 0.85D;
            guna2BorderlessForm1.ShadowColor = Color.Cyan;
            guna2BorderlessForm1.TransparentWhileDrag = true;
            // 
            // guna2ControlBox1
            // 
            guna2ControlBox1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            guna2ControlBox1.Animated = true;
            guna2ControlBox1.BackColor = Color.Transparent;
            guna2ControlBox1.CustomizableEdges = customizableEdges3;
            guna2ControlBox1.FillColor = Color.Transparent;
            guna2ControlBox1.IconColor = Color.Cyan;
            guna2ControlBox1.Location = new Point(250, 1);
            guna2ControlBox1.Name = "guna2ControlBox1";
            guna2ControlBox1.PressedColor = Color.FromArgb(0, 192, 192);
            guna2ControlBox1.ShadowDecoration.CustomizableEdges = customizableEdges4;
            guna2ControlBox1.Size = new Size(45, 29);
            guna2ControlBox1.TabIndex = 1;
            guna2ControlBox1.UseTransparentBackground = true;
            // 
            // guna2HtmlLabel1
            // 
            guna2HtmlLabel1.BackColor = Color.Transparent;
            guna2HtmlLabel1.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel1.ForeColor = Color.Cyan;
            guna2HtmlLabel1.Location = new Point(90, 71);
            guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            guna2HtmlLabel1.Size = new Size(126, 27);
            guna2HtmlLabel1.TabIndex = 2;
            guna2HtmlLabel1.Text = "WELCOME TO";
            // 
            // guna2HtmlLabel2
            // 
            guna2HtmlLabel2.BackColor = Color.Transparent;
            guna2HtmlLabel2.Font = new Font("Segoe UI Black", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel2.ForeColor = Color.Cyan;
            guna2HtmlLabel2.Location = new Point(51, 95);
            guna2HtmlLabel2.Name = "guna2HtmlLabel2";
            guna2HtmlLabel2.Size = new Size(208, 39);
            guna2HtmlLabel2.TabIndex = 3;
            guna2HtmlLabel2.Text = "ASTRO FREE V2";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Black;
            ClientSize = new Size(294, 362);
            ControlBox = false;
            Controls.Add(guna2HtmlLabel2);
            Controls.Add(guna2HtmlLabel1);
            Controls.Add(guna2ControlBox1);
            Controls.Add(gunaButton1);
            FormBorderStyle = FormBorderStyle.None;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Margin = new Padding(4, 3, 4, 3);
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "Form1";
            Opacity = 0.85D;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            Load += Form1_Load;
            Resize += Form1_Resize;
            ResumeLayout(false);
            PerformLayout();
        }

        private void Form1_Resize(object sender, EventArgs e)
        {
            if (WindowState == FormWindowState.Maximized || WindowState == FormWindowState.Minimized)
            {
                WindowState = FormWindowState.Normal;
            }
        }
    }
}
